-- lib/keynames.lua
local keynames = {}

-- Таблица: код клавиши -> имя
local keyCodeToName = {
    -- Буквы
    [0x41]="KEY_A",[0x42]="KEY_B",[0x43]="KEY_C",[0x44]="KEY_D",
    [0x45]="KEY_E",[0x46]="KEY_F",[0x47]="KEY_G",[0x48]="KEY_H",
    [0x49]="KEY_I",[0x4A]="KEY_J",[0x4B]="KEY_K",[0x4C]="KEY_L",
    [0x4D]="KEY_M",[0x4E]="KEY_N",[0x4F]="KEY_O",[0x50]="KEY_P",
    [0x51]="KEY_Q",[0x52]="KEY_R",[0x53]="KEY_S",[0x54]="KEY_T",
    [0x55]="KEY_U",[0x56]="KEY_V",[0x57]="KEY_W",[0x58]="KEY_X",
    [0x59]="KEY_Y",[0x5A]="KEY_Z",

    -- Цифры
    [0x30]="KEY_0",[0x31]="KEY_1",[0x32]="KEY_2",[0x33]="KEY_3",
    [0x34]="KEY_4",[0x35]="KEY_5",[0x36]="KEY_6",[0x37]="KEY_7",
    [0x38]="KEY_8",[0x39]="KEY_9",

    -- Функциональные клавиши
    [0x70]="KEY_F1",[0x71]="KEY_F2",[0x72]="KEY_F3",[0x73]="KEY_F4",
    [0x74]="KEY_F5",[0x75]="KEY_F6",[0x76]="KEY_F7",[0x77]="KEY_F8",
    [0x78]="KEY_F9",[0x79]="KEY_F10",[0x7A]="KEY_F11",[0x7B]="KEY_F12",

    -- Спецклавиши
    [0x08]="KEY_BACKSPACE",[0x09]="KEY_TAB",[0x0D]="KEY_ENTER",
    [0x10]="KEY_SHIFT",[0x11]="KEY_CTRL",[0x12]="KEY_ALT",
    [0x1B]="KEY_ESCAPE",[0x20]="KEY_SPACE",

    -- Стрелки
    [0x25]="KEY_LEFT",[0x26]="KEY_UP",[0x27]="KEY_RIGHT",[0x28]="KEY_DOWN",

    -- NumPad
    [0x60]="KEY_NUM0",[0x61]="KEY_NUM1",[0x62]="KEY_NUM2",[0x63]="KEY_NUM3",
    [0x64]="KEY_NUM4",[0x65]="KEY_NUM5",[0x66]="KEY_NUM6",[0x67]="KEY_NUM7",
    [0x68]="KEY_NUM8",[0x69]="KEY_NUM9",[0x6A]="KEY_NUMMULTIPLY",
    [0x6B]="KEY_NUMPLUS",[0x6C]="KEY_NUMENTER",[0x6D]="KEY_NUMMINUS",
    [0x6E]="KEY_NUMDOT",[0x6F]="KEY_NUMDIVIDE",

    -- Другие
    [0x2E]="KEY_DELETE",[0x2D]="KEY_INSERT",[0x24]="KEY_HOME",
    [0x23]="KEY_END",[0x21]="KEY_PAGEUP",[0x22]="KEY_PAGEDOWN",
    [0xC0]="KEY_TILDE",[0xBD]="KEY_MINUS",[0xBB]="KEY_EQUALS",
    [0xDB]="KEY_LBRACKET",[0xDD]="KEY_RBRACKET",[0xDC]="KEY_BACKSLASH",
    [0xBA]="KEY_SEMICOLON",[0xDE]="KEY_APOSTROPHE",[0xBC]="KEY_COMMA",
    [0xBE]="KEY_PERIOD",[0xBF]="KEY_SLASH"
}

-- Таблица обратная: имя -> код
local nameToKeyCode = {}
for code,name in pairs(keyCodeToName) do
    nameToKeyCode[name] = code
end

-- Получить имя клавиши по коду
function keynames.getName(code)
    return keyCodeToName[code] or "UNKNOWN"
end

-- Получить код клавиши по имени
function keynames.getCode(name)
    return nameToKeyCode[name] or -1
end

return keynames